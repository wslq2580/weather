package com.jie.weather.utils;

/**
 * @author panilsy@icloud.com
 * @description 回调函数
 */
public class CallBack implements ICallBack {
    @Override
    public void run(String s) {
    }
}