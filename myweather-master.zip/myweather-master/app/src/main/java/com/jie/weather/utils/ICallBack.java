package com.jie.weather.utils;

public interface ICallBack {
    void run(String s);
}